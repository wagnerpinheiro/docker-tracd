

if __name__ == '__main__':
    from agilo.test.testfinder import run_unit_tests
    run_unit_tests(root_dir=__file__)

