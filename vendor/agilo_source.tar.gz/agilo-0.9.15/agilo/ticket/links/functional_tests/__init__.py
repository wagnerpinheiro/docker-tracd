

if __name__ == '__main__':
    from agilo.test.testfinder import run_all_tests
    run_all_tests(root_dir=__file__)

