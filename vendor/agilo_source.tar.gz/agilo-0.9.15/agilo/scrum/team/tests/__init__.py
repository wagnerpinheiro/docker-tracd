# -*- encoding: utf-8 -*-

from agilo.test.testfinder import run_unit_tests

if __name__ == '__main__':
    run_unit_tests(root_dir=__file__)

